#!/usr/bin/env bash
# 在【登录终端】跑,前台常驻。build 期间必须开着。
# 用 HTTP 服务本地 ROS 源,避免把 1-2 GB 塞进 build context(vfs storage 下会非常慢)。
# build 走 --network=host,所以容器里的 127.0.0.1 就是宿主。
set -eu
OUT=${OUT:-/storage/home/yehe8/openrua-local/rosrepo}   # 持久盘,见 mkrosrepo.sh 里的注释
PORT=${PORT:-8899}
echo "serving $OUT on http://127.0.0.1:$PORT/  (Ctrl-C 停)"
cd "$OUT" && exec python3 -m http.server "$PORT" --bind 127.0.0.1
