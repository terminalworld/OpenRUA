#!/usr/bin/env python3
"""把两个 Dockerfile 改成从本地 ROS 源装包(免白名单)。

  python3 patch-dockerfiles.py apply     # 打补丁,原文件存为 *.orig
  python3 patch-dockerfiles.py revert    # 还原

只做一件事:在 apt-get install 之前,把不可达的 packages.ros.org 源换成
http://127.0.0.1:8899(serve-rosrepo.sh)。**包列表一字不改** —— 这是把与基线的
偏离压到"同样的官方 deb、可能不同快照版本"的关键;版本清单见 $OUT/Packages。

build 必须带 --network=host(build-images.sh 已经带了),127.0.0.1 才是宿主。
"""
import pathlib
import sys

ROOT = pathlib.Path("/storage/home/yehe8/OpenRUA/openrua")
TARGETS = [ROOT / "robot/sim/Dockerfile.jazzy", ROOT / "sandbox/sandbox.Dockerfile"]

SNIPPET = """# --- openrua-local: packages.ros.org 不在本 pod 的出网白名单里,换成 mkrosrepo.sh
# 从公开镜像 dpkg-repack 出来的本地源。包列表未改动。见 RUNBOOK §0.0b-4。
RUN rm -f /etc/apt/sources.list.d/ros2*.list /etc/apt/sources.list.d/ros2*.sources \\
    && echo 'deb [trusted=yes] http://127.0.0.1:8899/ ./' > /etc/apt/sources.list.d/local-ros.list
"""


def apply() -> None:
    for f in TARGETS:
        text = f.read_text()
        if "local-ros.list" in text:
            print(f"already patched: {f}")
            continue
        idx = text.index("RUN apt-get update")
        f.with_suffix(f.suffix + ".orig").write_text(text)
        f.write_text(text[:idx] + SNIPPET + text[idx:])
        print(f"patched: {f}")


def revert() -> None:
    for f in TARGETS:
        orig = f.with_suffix(f.suffix + ".orig")
        if orig.exists():
            f.write_text(orig.read_text())
            orig.unlink()
            print(f"reverted: {f}")
        else:
            print(f"no backup: {f}")


if __name__ == "__main__":
    {"apply": apply, "revert": revert}[sys.argv[1]]()
