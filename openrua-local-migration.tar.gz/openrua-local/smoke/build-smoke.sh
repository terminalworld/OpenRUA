#!/bin/bash
# 冒烟镜像三件套:在**不加出网白名单**的前提下把三个镜像建出来。
#
#   bash /storage/home/yehe8/openrua-local/smoke/build-smoke.sh 2>&1 | tee /tmp/smoke-build.log
#
# 前提:podman service 已由登录终端拉起且带 TMPDIR=/containers/yehe8/tmp
#      (build-images.sh 的 §A 会做这件事)。
#
# 与正式镜像的差异只在 base(见三个 Dockerfile 顶部的注释):
#   robot    ros:jazzy            -> moveit/moveit2:jazzy-release
#   sandbox  ros:jazzy            -> moveit/moveit2:jazzy-release + dpkg-repack 两个包
#   proxy    alpine:3.20          -> ubuntu:24.04
# tag 沿用正式名(openrua-sim-jazzy / openrua-sandbox-jazzy / openrua-proxy),
# 因为 robot profile 的 ros_distro 决定了 up 去找哪个名字,改名就跑不起来。
# ⚠️ 所以**正式跑批前必须重建**:白名单到手后跑 build-images.sh,覆盖回原版。

set -u
export PATH="$HOME/.local/bin:$PATH"
export TMPDIR=/containers/yehe8/tmp
OPENRUA=/storage/home/yehe8/OpenRUA
HERE=/storage/home/yehe8/openrua-local/smoke
AGENT=claude-code@2.1.251        # Fable 5.1 的 CLI 版本下限(runbook §6.1)

say() { printf '\n=== %s ===\n' "$*"; }
docker info >/dev/null 2>&1 || { echo "podman service 不在;先跑 build-images.sh"; exit 1; }

# --- 0. 用 openrua 自己的 API 算出 preinstall / whitelist / label ------------
# 手抄这些字符串就会与 doctor 的校验对不上,所以一律从源头取。
say "0. 从 agent manifest 取 preinstall / whitelist"
python3 - "$AGENT" <<'PY'
import sys
from openrua import agents
from openrua.cli.commands.build import manifests_for, agent_labels
m = manifests_for([sys.argv[1]], None)
open('/tmp/smoke.preinstall', 'w').write(agents.preinstall(m))
open('/tmp/smoke.whitelist', 'w').write("\n".join(agents.whitelist(m)))
for kind, path in (("install", "/tmp/smoke.labels.install"),
                   ("whitelist", "/tmp/smoke.labels.whitelist")):
    with open(path, 'w') as f:
        for k, v in agent_labels(m, kind).items():
            f.write(f"{k}={v}\n")
import hashlib
open('/tmp/smoke.preinstall.sha', 'w').write(
    hashlib.sha256(agents.preinstall(m).encode()).hexdigest())
open('/tmp/smoke.whitelist.sha', 'w').write(
    hashlib.sha256("\n".join(agents.whitelist(m)).encode()).hexdigest())
PY
[ -s /tmp/smoke.preinstall ] || { echo "preinstall 为空,agent 名可能写错"; exit 1; }
echo "preinstall: $(cut -c1-90 /tmp/smoke.preinstall)..."
echo "whitelist : $(tr '\n' ' ' < /tmp/smoke.whitelist)"

lbl() { while IFS= read -r l; do printf -- '--label\n%s\n' "$l"; done < "$1"; }

# --- 1. robot ---------------------------------------------------------------
say "1. openrua-sim-jazzy"
docker build -f "$HERE/Dockerfile.robot" -t openrua-sim-jazzy \
  --label "openrua.dockerfile_sha256=$(sha256sum "$HERE/Dockerfile.robot" | cut -d' ' -f1)" \
  --label "openrua.built_utc=$(date -u +%Y-%m-%dT%H:%M:%S+00:00)" \
  "$HERE" 2>&1 | tail -25
echo "rc=${PIPESTATUS[0]}"

# --- 2. sandbox -------------------------------------------------------------
say "2. openrua-sandbox-jazzy(含 agent CLI ${AGENT#*@})"
mapfile -t LBL < <(sed 's/^/--label=/' /tmp/smoke.labels.install)
docker build -f "$HERE/Dockerfile.sandbox" -t openrua-sandbox-jazzy \
  --build-arg "ROS_DISTRO=jazzy" \
  --build-arg "ROBOT_UID=$(id -u)" \
  --build-arg "PREINSTALL=$(cat /tmp/smoke.preinstall)" \
  --label "openrua.preinstall_sha256=$(cat /tmp/smoke.preinstall.sha)" \
  "${LBL[@]}" \
  "$HERE" 2>&1 | tail -25
echo "rc=${PIPESTATUS[0]}"

# --- 3. proxy ---------------------------------------------------------------
# context 用 openrua/proxy:Dockerfile 要 COPY 那份 tinyproxy.conf。
say "3. openrua-proxy"
mapfile -t LBLW < <(sed 's/^/--label=/' /tmp/smoke.labels.whitelist)
docker build -f "$HERE/Dockerfile.proxy" -t openrua-proxy \
  --build-arg "WHITELIST=$(cat /tmp/smoke.whitelist)" \
  --build-arg "PORT=8888" \
  --label "openrua.whitelist_sha256=$(cat /tmp/smoke.whitelist.sha)" \
  "${LBLW[@]}" \
  "$OPENRUA/openrua/proxy" 2>&1 | tail -25
echo "rc=${PIPESTATUS[0]}"

# --- 4. 验收 ----------------------------------------------------------------
say "4. 镜像与自检"
docker images | grep -E 'openrua|REPOSITORY'
echo "--- sandbox 里 agent CLI 版本(preflight 会校验 = 2.1.251)---"
docker run --rm openrua-sandbox-jazzy bash -lc 'claude --version' 2>&1 | tail -2
echo "--- sandbox 里 12 个 ROS 包 ---"
docker run --rm --user root openrua-sandbox-jazzy bash -lc '
for p in ros-jazzy-image-view ros-jazzy-cv-bridge ros-jazzy-tf2-tools ros-jazzy-tf2-ros \
         ros-jazzy-urdfdom-py ros-jazzy-control-msgs ros-jazzy-moveit-msgs; do
  printf "%-38s " "$p"; dpkg -s "$p" >/dev/null 2>&1 && echo YES || echo MISSING; done' 2>&1 | tail -10
echo "--- robot 里 move_group ---"
docker run --rm openrua-sim-jazzy bash -lc 'ls /opt/ros/jazzy/lib/moveit_ros_move_group/move_group' 2>&1 | tail -2

say "5. doctor"
openrua doctor panda --bench libero_pro
echo
echo "doctor 的 dockerfile/preinstall label 行可能报 stale —— 冒烟镜像本就来自不同的"
echo "Dockerfile,属预期。login 行走 token-file 时也是误报(runbook §6.4)。"
echo "下一步:openrua install --bench libero_pro(25-30 GB,宿主侧,走 session proxy 取 PyPI/GitHub)"
