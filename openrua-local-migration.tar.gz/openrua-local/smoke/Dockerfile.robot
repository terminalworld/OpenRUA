# 冒烟版 robot 镜像 —— 与 openrua/robot/sim/Dockerfile.jazzy 的唯一区别是 FROM。
#
# 为什么:本 pod 的出网白名单里没有 packages.ros.org(archive.ubuntu.com 有),
# 所以 `ros-jazzy-*` 装不上。moveit/moveit2:jazzy-release 是 Ubuntu 24.04 + Jazzy,
# 已含原 Dockerfile 需要的全部 ROS 包(实测:control-msgs / tf2-ros-py /
# robot-state-publisher / moveit-resources-panda-moveit-config 齐全,moveit 本身
# 以 84 个组件包的形式安装,move_group 可执行文件在位;只有元包名 ros-jazzy-moveit
# 未安装,功能不缺)。
#
# ⚠️ 代价:MoveIt 版本 = 该镜像发布时的版本,未必等于基线那次从 packages.ros.org
# 装到的版本。规划行为可能不同 ⇒ **此镜像只用于冒烟,不出正式数字。**
FROM docker.io/moveit/moveit2:jazzy-release

# 基础镜像自带的 ROS 源在这里不可达,留着会让每次 apt-get update 报 Err;删掉。
RUN rm -f /etc/apt/sources.list.d/ros2*.list /etc/apt/sources.list.d/ros2*.sources

# 与原 Dockerfile 相同的 Ubuntu 侧包(ROS 侧的已在基础镜像里):
# - python3.12-venv:base 缺 ensurepip
# - Mesa GL/EGL:MUJOCO_GL=egl + PYOPENGL_PLATFORM=egl 软渲染(llvmpipe,无 GPU)
# - Mesa Vulkan(lavapipe):SAPIEN 走 Vulkan
RUN apt-get update && apt-get install -y --no-install-recommends \
    python3.12-venv \
    libegl1 libgl1 libgles2 libglvnd0 libglx0 \
    libgl1-mesa-dri libglx-mesa0 libegl-mesa0 \
    libvulkan1 mesa-vulkan-drivers \
    libmagickwand-6.q16-7t64 \
    && rm -rf /var/lib/apt/lists/*

ENV MUJOCO_GL=egl PYOPENGL_PLATFORM=egl
