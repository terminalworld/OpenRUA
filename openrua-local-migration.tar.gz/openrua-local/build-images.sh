#!/bin/bash
# 在**普通登录终端**里跑(不能经 agent 会话):
#
#   bash /storage/home/yehe8/openrua-local/build-images.sh 2>&1 | tee /tmp/openrua-build.log
#
# 为什么必须由人跑 —— TerminalWorld runbook §2/§3 已记录、本机今天复测一致:
#   agent 会话是"受限进程"(CapEff=0000000000000000),setuid 程序与 chmod/chown 被拦,
#   且**没有出网**;"disable sandbox" 开关解除不了,setsid 也逃不掉。
#   podman **service 继承拉起它的那个进程的能力** —— 由受限进程拉起的 service,
#   它建的容器同样没有出网,表现就是 build 到 apt 那一步失败。
#   ⇒ 09-10 的 `exit status 100` 极可能正是此因(TW runbook 原话:
#     "a service with none cannot build anything ... otherwise only surfaces as
#      an apt failure several minutes into a build")。本脚本因此**强制校验 CapEff**。

set -u
OPENRUA=/storage/home/yehe8/OpenRUA
LOGDIR=/storage/home/yehe8/openrua-local

# 受限会话门禁 + podman service(含 TMPDIR=/containers/yehe8/tmp)全在这里
source /storage/home/yehe8/openrua-local/ensure-podman.sh

# --- B. 容器视角的出网(不是宿主视角!)------------------------------------
# TW §2:容器出网**只有明文**,TLS 到公网被拦(curl exit 35)。
# 所以这里必须在容器里探,宿主上探是无效的。
say "B. 容器内出网探测"
# 用 busybox 自带的 wget:alpine 基础镜像里没有 curl(上一版 apk add 失败被吞掉了),
# 而容器装 curl 本身就依赖出网 —— 探测工具不能依赖被探对象。
docker run --rm --network=host docker.io/library/alpine:3.20 sh -c '
  for u in http://archive.ubuntu.com/ubuntu/dists/noble/Release \
           http://packages.ros.org/ros2/ubuntu/dists/noble/Release \
           https://packages.ros.org/ros2/ubuntu/dists/noble/Release \
           https://registry.npmjs.org/ \
           https://deb.nodesource.com/setup_20.x ; do
    printf "%-62s " "$u"
    if wget -q -T 15 -O /dev/null "$u" 2>/dev/null; then echo OK; else echo "FAIL rc=$?"; fi
  done' 2>&1 | tee "$LOGDIR/egress-probe.log"
echo "读法:http 行 OK 说明明文出网正常;https 行 FAIL 即 TLS 被拦,该源只能改明文或宿主预取。"

# --- C. robot 镜像:完整日志 ------------------------------------------------
# 与 openrua/robot/sim/build.py:33-41 逐字一致(含两个 label,doctor 靠 label 判新旧);
# 唯一差别是不截断 stderr —— openrua 只回显最后 2000 字符,09-10 的真因就是被它吃掉的。
say "C. build openrua-sim-jazzy(完整输出)"
DF="$OPENRUA/openrua/robot/sim/Dockerfile.jazzy"
SHA=$(sha256sum "$DF" | cut -d' ' -f1)
docker build -f "$DF" -t openrua-sim-jazzy \
  --label "openrua.dockerfile_sha256=$SHA" \
  --label "openrua.built_utc=$(date -u +%Y-%m-%dT%H:%M:%S+00:00)" \
  "$OPENRUA/openrua/robot/sim" 2>&1 | tee "$LOGDIR/build-robot-full.log"
RC=${PIPESTATUS[0]}
echo "robot build rc=$RC  (完整日志: $LOGDIR/build-robot-full.log)"
[ "$RC" -ne 0 ] && { echo "把 build-robot-full.log 和 egress-probe.log 贴回来。"; exit 1; }

# --- D. sandbox:预期会挂,原因已知 -----------------------------------------
# sandbox 镜像靠 `npm install -g @anthropic-ai/claude-code@2.1.251`,走 HTTPS。
# 若 §B 的 npmjs 行不是 200,这一步必然失败,解法是宿主 `npm pack` → 塞进 build
# context → 从 tarball 装(TW 对 PyPI wheel 用的同一招),需要改 agent manifest 的
# install 行。先跑一次拿到确切报错再决定。
say "D. build sandbox(claude-code@2.1.251;Fable 5.1 的版本下限)"
openrua build sandbox --distro jazzy --agent claude-code@2.1.251 2>&1 | tee "$LOGDIR/build-sandbox.log"
echo "sandbox rc=${PIPESTATUS[0]}"

# --- E. proxy ---------------------------------------------------------------
# 只是先建一个能让 doctor 转绿的版本。跑实验前**必然要重建**:runbook §6.4 要给
# tinyproxy.conf 加 Upstream 指向 x2p 网关、白名单加网关 host;且 §6.4 记的
# 10.0.2.2 是 slirp4netns 时代的地址,podman 6 + netavark/pasta 下要重测。
say "E. build proxy(临时版)"
openrua build proxy --agent claude-code 2>&1 | tee "$LOGDIR/build-proxy.log"
echo "proxy rc=${PIPESTATUS[0]}"

say "F. doctor"
docker images | grep -E 'openrua|REPOSITORY'
openrua doctor panda --bench libero_pro
echo
echo "预期:除 login 行外零 error(走 token-file 时 login 是误报,runbook §6.4)。"
echo "下一步 §5 模拟器安装(25-30 GB),再 §7 冒烟一局。"
