# OpenRUA 本地 runbook — Fable 5.1 × LIBERO-PRO **LIBERO-10** 两格

本机:`/storage/home/yehe8/OpenRUA`(upstream `terminalworld/OpenRUA` @ `9d06272`)
工作目录:`/storage/home/yehe8/openrua-local/`
目标(2026-09-11 改定):**`libero_10_task` + `libero_10_swap`**,各 10 task × 10 seed
= 200 局,对齐 Opus 5 的 **65/100 + 80/100**。这两格是整张网格里成功率最低、区分度最大的
一对(LIBERO-10 = 长程两段式任务),优先于原定的 goal 两格(Opus 5 79/79)。
goal 两格的记录保留在本文件里,协议完全相同,只换 `--task-suite` 与 `--run-id`。

状态记于每节标题旁:✅ 已完成 / ⛔ 阻断 / ⏸ 待输入

---

## 0. 当前阻断 ⛔

### 0.0 2026-09-11 实测:平台又退了一步 ⛔

§0.1/§0.2 记的是**系统 podman 3.4.4**。此后已经绕过:`~/.local/bin/docker` 不再是
symlink,而是一个转发到**静态 podman 6.1.1**(`~/podman-static/v611`,netavark +
aardvark-dns,§0.1 的 CNI 阻断因此消失)remote service 的脚本,并额外做两件本机适配 ——
`build` 子命令自动加 `--network=host`(本 pod 的 169.254 出网只在宿主网络命名空间内有效),
`DOCKER_CONFIG=/tmp/dockercfg`(躲开宿主 `~/.docker/config.json` 里的 ECR credential helper)。

**但今天(09-11)这条路也起不来了:**

```
$ podman system service --time=0 unix:///tmp/podman-static.sock
Error: cannot set up namespace using "/usr/bin/newuidmap": fork/exec ...: operation not permitted
$ /usr/bin/newuidmap            # setuid root,-rwsr-xr-x
bash: /usr/bin/newuidmap: Operation not permitted
```

同一台 `yehe8-login-0`。逐条实测下来,这**不是** pod 的权限退化,而是**执行层的二进制黑名单**:

| 探测 | 结果 | 含义 |
|---|---|---|
| `/usr/bin/{newuidmap,newgidmap,passwd,su,ping}` | 全部 `rc=126` Operation not permitted | 特权助手被拦 |
| `/usr/bin/{ls,id,cat}`、`/opt/conda/bin/python` | 正常 | **不是**整个 `/usr/bin` 被拦 |
| `/usr/bin/chmod` | 被拦 —— 但它**不是 setuid** | 拦的是"能改权限的程序",按名单不按 setuid 位 |
| `os.chmod()` 系统调用、`/tmp` 下自建脚本 | 正常 | 内核能力还在,拦的是 **execve 特定二进制** |
| `cp /usr/bin/chmod /tmp/x && /tmp/x` | **正常** | 判据是**原路径/inode**,复制品不受限 |
| `/proc/self/status` | `Seccomp: 0`、`NoNewPrivs: 0`、`TracerPid: 0`、初始 userns | 常规机制都排除了 |
| `unshare -U` / `unshare -r` | 正常 | 用户命名空间本身可用 |

**为什么这就卡死 rootless podman**:多 ID 映射(`/etc/subuid` 的 65536 段)只能由 root 所有的
setuid `newuidmap` 写入。绕不过 ——

- 复制一份 `newuidmap` → 属主变成 `yehe8`,setuid 位毫无意义;
- 硬链接原文件保权限 → `protected_hardlinks=1`,`ln` 直接 EPERM;
- 退化成**单 UID 模式**(无 subuid)→ podman 能起,但 OpenRUA 的 `--userns=keep-id` 正是要多 ID
  映射,且镜像构建里的 `useradd`/`chown` 会失败(很可能就是 09-10 那个 apt `exit 100`)。

**这几乎可以确定是 agent 会话沙箱的策略,不是 fair-sc 的 pod 策略。** 扩大探测后的形状:

- **所有 setuid / setgid 位的程序无一例外被拦**:`sudo` `mount` `umount` `su` `passwd`
  `gpasswd` `chsh` `chfn` `newgrp` `ping` `fusermount3` `crontab` `newuidmap` `newgidmap`
- **外加按名字拦掉 `chmod` 和 `chown`** —— 这两个**都不是 setuid**
- 而 `chgrp` `setcap` `dd` `tar` `xargs` `env` 全部放行

一条 pod 级的 `nosuid` 挂载或 SELinux 规则**解释不了 `chmod`/`chown` 被拦而 `chgrp` 放行**
—— 那是一份**人工维护的黑名单**(禁提权 + 禁改权限),即会话沙箱的特征。
`dangerouslyDisableSandbox` 也解除不了它。

**佐证:这台 pod 的 podman 本来就是好的。** TerminalWorld 就是在同一台
`yehe8-login-0` 上用 rootless podman 3.4.4 跑通的(见姊妹 runbook),而 09-10 静态 podman
6.1.1 也确实 build 到了 apt 那一步 —— 两者都需要 `newuidmap`。
另注:`/containers/yehe8/` 与 `~/.local/share/containers/cache` 的 mtime 都是 **09-11 10:03**,
pod 今早重建过。

**已证实(2026-09-11):** 在普通终端里 `/usr/bin/newuidmap --help; echo $?` → **rc=1**。
pod 完全正常,podman 可用。**§0.0 不是新增阻断,只是"agent 会话跑不了 build"。**

⇒ 操作模式定为:**镜像构建与全量跑批由人在普通终端执行,agent 只做配置、分析、写文档。**
一键脚本已备:

```bash
bash /storage/home/yehe8/openrua-local/build-images.sh 2>&1 | tee /tmp/openrua-build.log
```

(它拉起 podman service → 探出网 → **不截断**地 build robot 镜像 → 失败则单独跑 apt 诊断
→ 成功则建 sandbox\@2.1.251 与 proxy → `openrua doctor`。
robot 那一步是直调 `docker build`,命令与两个 label 与 `robot/sim/build.py:33-41` 逐字一致,
因此 doctor 的 label 校验照常通过。脚本没有可执行位 —— agent 沙箱连 `chmod` 都拦 —— 用 `bash` 起。)

### 0.0b apt `exit 100` 的首要嫌疑:service 是被受限进程拉起的

姊妹 runbook(TerminalWorld)§2/§3 把这台机器的这条性质记得很清楚,与今天实测完全吻合:

> podman **service 继承拉起它的那个进程的能力**。从 agent 会话(`CapEff=0`)里拉起的
> service,它建的容器**没有出网**;TW 原话:"a service with none cannot build anything …
> otherwise **only surfaces as an apt failure several minutes into a build**"。

09-10 的 `exit status 100` 正是"build 几分钟后 apt 失败"。**先验证再谈别的**:

```bash
grep CapEff /proc/$(pgrep -f 'podman system service' | head -1)/status
# 要 000001ffffffffff;若是 0000000000000000,杀掉、从登录终端重起即可
```

⚠️ **这条 CapEff 判据只对 service 成立,不能拿来判你自己的 shell。**
podman service 会 re-exec 进 userns,在那里持有全部能力;而**任何非 root shell 的 CapEff
都是全 0**,登录终端也是 —— 拿它判"是不是受限会话"会把登录终端也误杀(已踩)。
判受限会话请用功能判据:`/usr/bin/newuidmap --help; echo $?` —— **登录终端 1,受限会话 126**
(`chmod` 同理:0 vs 126)。`build-images.sh` 的门禁用的就是后者。

### 0.0b-2 实测新增坑:build context 的 overlay 不能落在 /var/tmp ✅ 已解

2026-09-11 首次真正跑起 build,报:

```
Error: mounting an overlay over build context directory: ...
  lowerdir=/var/tmp/libpod_builder.../build,...,userxattr: invalid argument
```

buildah 会把 build context 挂成一层 overlay,默认落在 `/var/tmp`。而本 pod:

| 路径 | fstype | 能否作 overlay 的 lowerdir |
|---|---|---|
| `/var/tmp`、`/tmp` | **overlayfs**(containerd rootfs) | ❌ overlay 套 overlay → EINVAL |
| `/storage/home` | **nfs** | ❌ |
| `/containers`(2.2 T,`/dev/md0`) | **xfs** | ✅ |

解:**给 podman service 设 `TMPDIR=/containers/yehe8/tmp`**。注意 remote build 的临时目录
建在 **service 端**,所以要设在 service 的环境里,客户端设没用。`build-images.sh` 已内置,
并会检查在跑的 service 是否带了这个变量,不带就换掉它。

另:同一次运行里 `docker.io/library/alpine:3.20` **拉取成功** —— registry 出网是通的,
且这个 service 由登录终端拉起,能力正常。

### 0.0b-3 apt `exit 100` 的真因(2026-09-11 拿到完整日志)⛔ 当前唯一阻断 → **见 §0.0b-4 的免白名单解**

不是能力问题,也不是 TLS 问题,是**出网白名单少了一个 host**:

```
Err:1 http://packages.ros.org/ros2/ubuntu noble InRelease
  Connection failed [IP: 169.254.192.10 80]
...
E: Unable to locate package ros-jazzy-moveit
```

`archive.ubuntu.com` / `security.ubuntu.com` 全程 200(32.6 MB 索引正常拉完),
**只有 `packages.ros.org` 连不上** —— 于是三个 ROS 包找不到,apt 退 100。

容器出网实测(§B 探测 + build 日志):

| host | 容器内 | 判定 |
|---|---|---|
| `archive.ubuntu.com` / `security.ubuntu.com` | ✅ 200 | Ubuntu 包没问题 |
| `registry.npmjs.org`(**HTTPS**) | ✅ | **sandbox 镜像的 npm 能装 —— §0.0c-1 的担心不成立** |
| `deb.nodesource.com`(**HTTPS**) | ✅ | 同上 |
| `docker.io` registry | ✅ | 基础镜像可拉 |
| `packages.ros.org` | ❌ http 与 https 都不通 | **唯一缺口** |

宿主侧三条路都试过,没有一条能到 ROS 源:直连 000、session proxy **403**、x2p **503**
(与 TW §2 记的"session proxy 拒绝一切 Debian 镜像"一致;但注意 `deb.nodesource.com`
是通的 —— 说明白名单是**按 host** 而不是按"是不是 apt 源",所以加一个 host 是合理请求)。

两条出路,**都会让 robot 镜像偏离基线**,取舍要先定:

1. **请 fair-sc 把 `packages.ros.org` 加进出网白名单**(推荐)。Dockerfile 一字不改,
   `openrua.dockerfile_sha256` 与基线一致,provenance 可比性完好。代价是等审批。
2. **换基础镜像**:Docker Hub 上有 `moveit/moveit2:jazzy-release`(已查,tag 存在)。
   改 `FROM` 就绕开了 ROS 源,但 **MoveIt 版本可能与基线不同 → 规划行为不同 → 成功率不可比**。
   这比 §6.1 那个 CLI 版本漂移严重得多(那个只影响 agent,这个直接影响机器人执行)。
   只建议作为"先跑通冒烟、验证链路"的临时手段,不要用它出正式数字。

#### 换 base 到底能不能免掉白名单:实测结论 = **robot 能,sandbox 不能**

先确认无审批的替代源确实只剩镜像 —— 六个 ROS 源在容器里**全部不通**:
`packages.ros.org`、`snapshots.ros.org`、`repo.ros2.org`、清华 / 中科大 / 阿里云镜像,
只有 `archive.ubuntu.com` OK。所以候选只有 Docker Hub 上现成的镜像。

`docker.io/moveit/moveit2:jazzy-release`(Ubuntu 24.04 + Jazzy)实测:

| 镜像 | 需要的包 | 命中 | 缺 |
|---|---|---|---|
| robot | 5 个 | 4 YES + `ros-jazzy-moveit` 只是**元包**没装,84 个组件齐全(`move_group` 可执行文件、ompl、panda config、simple-controller-manager 都在) | 实际不缺 ✅ |
| sandbox | 7 个 | 6 YES | **`ros-jazzy-image-view` 缺** ❌ |

关键取舍在这里:**sandbox 镜像就是 agent 的工作环境**,少一个感知工具 =
直接改变 agent 的可用手段,这比 robot 侧的版本漂移**更伤实验可比性**。
而 `image-view` 只在 ROS 源里有;`ros:jazzy-perception` 有它但没有 `moveit-msgs`
—— 两个候选 base **互补而不重叠**,无审批路径必然要拼接(多阶段 COPY 消息包之类),
拼出来的东西已经不能称为"同一个 harness"。

⇒ **定论:换 base 只适合把链路跑通做冒烟,正式数字仍需白名单(或同事的环境)。**
两者并行:白名单在审批期间,用 moveit2 base 跑通 §5 安装 + §7 冒烟,
验证 bridge、gateway 接入与单局成本;白名单一到,换回原版 Dockerfile 重建再跑正式 200 局。
冒烟镜像**打不同 tag**(`openrua-sim-jazzy-smoke`),别污染正式镜像名。

### 0.0b-4 免白名单方案(2026-09-11 下午,agent 实证)⭐ 当前首选

先纠正上一节一个隐含错误:**这台 pod 上不止一套白名单,至少两套,边界不同。**
(agent 会话实测:`getent hosts` 显示每个"已知" host 被映射到一个 `169.254.192.x`
虚拟 IP —— 出网是 **DNS 劫持式的按 host 代理**,不是普通 NAT。
`packages.ros.org` **能解析**到 `169.254.192.5`,说明它在 DNS 映射里,只是**连接被拒**
—— 白名单是在代理侧按 host 判的。)

| 通道 | archive.ubuntu | packages.ros.org | registry-1.docker.io | **docker CDN**(`production.cloudfront.docker.com`) | conda.anaconda.org | github.com | ghcr/quay |
|---|---|---|---|---|---|---|---|
| **容器 / build**(169.254 代理) | ✅ | ❌ | ✅ | ✅(镜像确实拉下来了) | ⏸ 待测 | ⏸ | ⏸ |
| **agent 会话 proxy** `127.0.0.1:38267` | ❌ | ❌ | ✅ 200 | ❌ 403 | ✅ **200** | ✅ 200 | ✅ 401(活着) |
| **agent 会话直连**(含 `dangerouslyDisableSandbox`) | ❌ 000 | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |

两条操作性结论:
1. **agent 会话完全没有直连出网**(host 侧 `curl --noproxy '*'` 全 000,只有 eth0 +
   `default via 169.254.1.1`)。所以**任何"容器里通不通"的问题,agent 都答不了** ——
   必须在登录终端跑 `probe-container-egress.sh`。这条要和 §0.0 的 `newuidmap` 并列记住。
2. 两套白名单**不是包含关系**(agent proxy 有 conda 没 docker CDN;容器有 docker CDN
   没 conda —— 后者待测)。**跨通道搬结论会错**,和 §0.0c-1 那次教训同一类。

#### 方案 A ⭐:把 Docker Hub 当 ROS apt 源用(`dpkg-repack`)

关键点:**我们要的 deb 已经装在若干公开镜像里**,而 Docker Hub 在容器里是通的。
`dpkg-repack`(在 Ubuntu universe,`archive.ubuntu.com` ✅ 可达)能把**已安装的包原样还原成
`.deb`**,dpkg 元数据 / 依赖 / 文件清单全部保留。汇成一个 flat apt 源之后:

> **两个 Dockerfile 的 apt install 包列表一字不改**,只多一行 sources.list。

这比 §0.0b-3 记的"换 base"好得多。偏离程度对比:

| 方案 | 装的是什么 | 与基线的差 |
|---|---|---|
| 白名单(理想) | 官方 deb,build 时点版本 | 0 |
| **A. dpkg-repack** | **同样的官方 deb**,源镜像的快照版本 | **仅版本号,且可枚举**(`$OUT/Packages`) |
| B. 换 base | 不同 base 的整棵 ROS 树 + sandbox 缺 image-view | 环境形状变了,sandbox 少一个感知工具 |
| C. RoboStack conda | conda 构建,装在 `/opt/conda` 而非 `/opt/ros` | 整个 harness 换了,不可比 |

源镜像取两个,互补覆盖(§0.0b-3 已实测过第一个):
`moveit/moveit2:jazzy-release`(moveit 全栈)+ `ros:jazzy-desktop-full`(image_view /
cv_bridge / tf2_tools 等)。**把两个镜像里所有 `ros-*` 包全部 repack**,而不是只挑那 12 个
—— 本地源里有完整依赖闭包,apt 才能自己解依赖,也才允许它升级 `ros:jazzy` 基础层里的旧包。

三步(全在登录终端):

```bash
L=/storage/home/yehe8/openrua-local/logs; mkdir -p $L   # 日志必须写持久盘,见 §0.0b-5
bash /storage/home/yehe8/openrua-local/mkrosrepo.sh 2>&1 | tee $L/mkrosrepo.log   # 造源
#   ↑ 必须看到 "本地源就绪" 才继续。它现在会在 pool 为空时直接 die。
bash /storage/home/yehe8/openrua-local/serve-rosrepo.sh &    # HTTP:8899,build 期间常驻
python3 /storage/home/yehe8/openrua-local/patch-dockerfiles.py apply
bash /storage/home/yehe8/openrua-local/build-images.sh 2>&1 | tee $L/openrua-build.log
```

⚠️ **别把这几条一次性粘进终端。** 它们不是流水线,是四个必须逐个确认结果的步骤
(15:00 那次就是一次性粘贴:`mkrosrepo` 在 podman service 还没起时跑,
所有 `docker run` 都是 `Cannot connect to Podman`,却继续往下走造出**空源**,
最后表现成 build 阶段一串 `404 /./Packages` —— 报错点离真因隔了三步)。

#### 由此修掉的三个脚本缺陷(2026-09-11)✅

1. **前置不能靠执行顺序。** 起 podman service 的逻辑原来只写在 `build-images.sh` 里,
   而 `probe` / `mkrosrepo` 都要用 docker。已抽成 `ensure-podman.sh`,三个脚本各自
   `source` 它 —— 每个脚本自带门禁,单独跑也对。
2. **`mkrosrepo.sh` 原来会静默产出空源。** 现在:源镜像里 `ros-*` 包数为 0 → 退 3;
   pool 里 deb 数为 0 → `die`;`$OUT/Packages` 不存在或为空 → `die`。
   **失败要在造源那一步就炸,不能留到 build。**
3. **`probe-container-egress.sh` §2 全是 `env: 'probe': No such file or directory`** ——
   `probe` 是 shell 函数,`env -u ...` 只能执行外部程序。改用 `curl --noproxy '*'`。

#### 这次跑出来的两条正面证据

- **补丁本身是对的。** `STEP 2/5` 换源那层建成了,`apt-get update` 确实去问了
  `http://127.0.0.1:8899`(`--network=host` 下容器里的 127.0.0.1 就是宿主,通),
  ROS 源也被干净地移除了,Ubuntu 源照常 32.6 MB 拉完。
  **失败纯粹是源里没东西**,方案 A 的机制部分已验证。
- **`CapEff` 判据对 service 也不可靠。** 这次 `build-images.sh` 报
  `pid=9381 CapEff=0000000000000000`,但紧接着 alpine 拉取成功、容器内 apt 出网正常。
  ⇒ §0.0b 那句"service 要 `000001ffffffffff`,否则没出网"**不成立**,
  它只是个警告,不要据此杀 service。**唯一可信的判据是容器内实测出网。**

另:15:00 那次 §3 x2p 全 000,但那**只说明代理端口没在监听**,不等于这些 host 不可达。
探测脚本现在先测端口,不在监听就整节跳过,免得又留下一屏误导性的 000。

为什么走 HTTP 而不是 `COPY` 进 build context:源有 1-2 GB,而本机 storage driver 是
**vfs**(§0.0c-3),大 context 会慢到不可接受。build 已经带 `--network=host`(§0.0),
所以容器里的 `127.0.0.1:8899` 就是宿主。

#### 首次造源实测(2026-09-11 15:12)—— repack 本身完全成立 ✅

⚠️ **产物已在 15:18 的 pod 重启中丢失(§0.0b-5),要重造;下面的结论本身仍然有效。**

`moveit/moveit2:jazzy-release` 一个源就 repack 出 **358 个 deb / 613 MB,零 WARN**。
快照日期整齐一致(`*-1noble.20260615.*` / `20260617.*`),即**单源内没有版本错位**。
两个缺口,都已解:

| 缺口 | 原因 | 解 |
|---|---|---|
| `ros:jazzy-desktop-full` → `manifest unknown` | **tag 写错了仓库**。官方 `library/ros` 的 jazzy 只有 `ros-core` / `ros-base` / `perception` 三个变体;`desktop` / `desktop-full` / `simulation` 在 **`osrf/ros`** 下 | 源镜像改成 `docker.io/osrf/ros:jazzy-desktop-full`(补 `image-view`) |
| `ros-jazzy-moveit` 不在池里 | moveit2 镜像是按组件装的,**没装那个空壳元包**,dpkg-repack 自然拿不到 | 脚本按上游 `moveit2@jazzy` 的 `moveit/package.xml` **合成**它 |

关于合成元包:ROS 元包**不含任何文件**,deb 里唯一有意义的内容就是 `Depends`,
而那是 bloom 从 `package.xml` 的 `exec_depend` 逐条生成的。已核对上游只有五条 ——
`moveit_core` / `moveit_planners` / `moveit_plugins` / `moveit_ros` / `moveit_setup_assistant`
—— 且**五个包都已在池中,版本齐齐是 2.12.4**。照这五条合成,装出来的**文件集与官方元包完全一致**;
Dockerfile 里 `ros-jazzy-moveit` 那一项因此不用动。
(与 §0.0b-3 那次"84 个组件齐全、只是元包没装"的实测互相印证。)
合成包的 `Maintainer` 写成 `openrua-local <synthesized>`,在 `$OUT/Packages` 里一眼可辨,
**记进 provenance**。

脚本末尾新增**覆盖率自检**:两个 Dockerfile 点名的 11 个 ros 包逐个在 `Packages` 里查,
缺任何一个直接 `die` —— 不让它拖到 build 才以 `exit 100` 暴露。

仍未验证:
- 跨源版本错位。加了 `osrf/ros:jazzy-desktop-full` 之后池里会同时有两个快照日期的包
  (moveit2 是 0615/0617,osrf 那个未知),apt 可能解不开。真撞上就退回"只用 moveit2 建源
  + sandbox 缺 image-view"(§0.0b-3 的 B 方案)。脚本对已存在的 deb 会跳过,所以
  **重跑是幂等的**,只会新增 osrf 独有的包。
- `dpkg-repack` 对含 `postinst`/conffile 的包一般没问题,失败的会打 `WARN` 跳过 —— **看日志**。

**记一笔进结论**:与基线之间的已知变量从此有两个 —— §6.1 的 agent CLI 2.1.226→2.1.251,
和这里的 ROS deb 快照版本(清单在 `$OUT/Packages`,建议连同 `provenance.json` 一起存档)。

#### 方案 C 兜底:RoboStack(conda)—— 覆盖率够,但不要用它出正式数字

`conda.anaconda.org` 在 **agent proxy 上 200**(容器侧待测)。查过 `robostack-jazzy` 频道,
本项目需要的 **10 个包全部存在**(`ros-jazzy-moveit` / `moveit-msgs` / `control-msgs` /
`image-view` / `cv-bridge` / `tf2-tools` / `tf2-ros-py` / `urdfdom-py` /
`robot-state-publisher` / `moveit-resources-panda-moveit-config`,均 200)。
但它装在 `/opt/conda` 而不是 `/opt/ros/${ROS_DISTRO}`,而 sandbox Dockerfile 的
`AMENT_PREFIX_PATH` / `BASH_ENV` / `PATH` 全部硬编码 `/opt/ros/...`(见 `sandbox.Dockerfile:51-66`)
—— 换过去等于重写镜像。**只在方案 A 也失败时才考虑,且只用于跑通链路。**

### 0.0b-5 ⭐ pod 会一天重启多次,`/containers` 是**易失**盘(2026-09-11 15:18 实测)

15:16 那次 `mkrosrepo.sh` 已经把 moveit2 的 358 个 deb 造好、正在拉第二个源镜像
`osrf/ros:jazzy-desktop-full`(blob 都拉完了、manifest 已写),然后 **`Session terminated`**。
不是脚本失败,也不是被 kill —— **整个 pod 重启了**:

```
$ ps -eo lstart,cmd --sort=start_time | head -2   # head -1 只有表头,要 -2
Fri Sep 11 15:18:27 2026  /package/admin/s6/command/s6-svscan ...   ← PID 1 的启动时刻
$ ls -ld /containers/yehe8
drwx--x--x. 2 yehe8 root 10 Sep 11 15:18 /containers/yehe8          ← 空目录,mtime = 重启时刻
```

同一天已经重启过两次(§0.0 记了 10:03,这次 15:18)。**要按"随时会重启"来设计每一步。**

**第三次:17:02:47**(15:38 重跑的 `mkrosrepo` 又断在第二个源镜像 `osrf/ros:jazzy-desktop-full`
的 repack 中途 —— 346 个包只做完 41 个)。⇒ **重启间隔约 1.5-2 小时**,而一次完整造源需要
约 20-30 分钟,勉强够;§8 的 200 局(中位 51 分钟/局)则完全不可行,§11 换机器的理由再加一条。
**这次的持久化改动生效了 ✅**:`/storage/home/.../rosrepo/pool` 里 **399 个 deb / 684 MB 完整存活**
(358 moveit2 + 41 osrf),只丢了 podman 镜像库。重跑只需补 osrf 剩下的约 305 个。
池里会留下中断的 `dpkg-repack.<pkg>.XXXXXX` 临时目录 —— 不是 `.deb`,`dpkg-scanpackages`
不会捡它们,可以不管(想干净就 `rm -rf $OUT/pool/dpkg-repack.*`)。

| 路径 | 挂载 | 跨 pod 重启 | 放什么 |
|---|---|---|---|
| `/storage/home`(= `/home/yehe8`) | fsx NFS,46 T 可用 | ✅ **持久** | **ROS 源、日志、runs、一切产物** |
| `/containers` | `/dev/md0` xfs 2.2 T | ❌ **清空** | 只放 podman graphroot 与 `TMPDIR`(必须 xfs) |
| `/tmp`、`/var/tmp` | overlayfs | ❌ 清空 | socket、pid 文件 |

这次的实际损失:

- `/containers/yehe8/rosrepo` 的 **358 个 deb / 613 MB 全没了**(§0.0b-4 那节的实测结论仍然成立,只是产物要重造)
- `/containers/yehe8/pstatic/vfs` = podman graphroot → **镜像库清零**,两个源镜像要重拉
- `/tmp/podman-static.sock` 与 podman service 进程没了 → 每次重启后都要重跑 `ensure-podman.sh`
- `tee /tmp/mkrosrepo.log` 的日志也一起没了 —— **日志别再写 /tmp**

已做的三处修改 ✅:

1. `mkrosrepo.sh` / `serve-rosrepo.sh` 的 `OUT` 默认值
   `/containers/yehe8/rosrepo` → **`/storage/home/yehe8/openrua-local/rosrepo`**。
   deb 池只是一堆普通文件,不需要 xfs;只有 `TMPDIR`(overlay lowerdir,§0.0b-2)才必须留在 `/containers`。
2. `mkrosrepo.sh` 每轮开头**清掉读不出 `dpkg-deb --field` 的 deb**。
   原来的跳过逻辑只看文件名,重启留下的截断文件会被当成"已完成",一路带进 `Packages`
   直到 build 才以校验和错误暴露。
3. 日志统一写持久盘:`tee /storage/home/yehe8/openrua-local/logs/<step>.log`。

**podman graphroot 不要搬到 NFS。** vfs 驱动靠 chown 与硬链接,NFS 上又慢又容易出错;
镜像重拉(约 5-10 分钟)比这个风险便宜。**只有产物需要持久,缓存不需要。**

### 0.0b-6 pod 重启后的恢复清单(每次重启都照做)

```bash
# 1. 确认真的重启了(PID 1 的启动时刻 = 本次 pod 的年龄;`uptime` 是宿主的,别看它)
ps -eo lstart,cmd --sort=start_time | head -2   # head -1 只有表头,要 -2

# 2. 重起 podman service(顺带重建 /containers/yehe8/tmp 与 socket)
source /storage/home/yehe8/openrua-local/ensure-podman.sh

# 3. 造源 —— 幂等,已在池里的 deb 会跳过,所以重启后重跑只补缺的那部分
mkdir -p /storage/home/yehe8/openrua-local/logs
bash /storage/home/yehe8/openrua-local/mkrosrepo.sh 2>&1 \
  | tee /storage/home/yehe8/openrua-local/logs/mkrosrepo.log
#    ↑ 必须看到 "本地源就绪" 才继续
```

第 3 步的镜像会重拉(graphroot 清空了),但 **deb 池在 NFS 上活着**,所以只补第二个源镜像
独有的包,不用从头 repack 358 个。

⚠️ **§8 的 200 局(单局中位 51 分钟、p90 234 分钟)在这种重启频率下没法直接串行跑完。**
在排全量之前必须先弄清:重启是 fair-sc 的常规回收,还是今天的偶发?
`openrua bench` 有 `.running` 锁,进程被 pod 重启杀掉会留下**过期锁**,
而 §8 记过"锁判活会 `SystemExit` 杀掉整个剩余队列" —— **重启 + 过期锁 = 整批断在半路**。
这一条要和 §11 的取环境一起考虑:它是"换一台机器"的又一个理由。

### 0.0c 另外三条从 TerminalWorld 直接继承的结论

1. ~~**容器出网只有明文,TLS 到公网被拦**(`curl` exit 35)。命中 OpenRUA 一处:
   sandbox 镜像的 `npm install -g @anthropic-ai/claude-code@2.1.251` 走 HTTPS,**大概率装不上**。~~
   **❌ 本机实测不成立(2026-09-11)**:`https://registry.npmjs.org` 与
   `https://deb.nodesource.com` 在容器里都通,sandbox 镜像不需要预取绕法。
   TW 的"只有明文"是**它那条链路**的性质(不同的 podman、不同的网络模式),
   不能直接搬到这里 —— 教训:**跨项目继承结论要重测**。下面这段保留作对照:
   解法是 TW 对 PyPI wheel 用过的那招:**宿主取包(`npm pack`)→ 塞进 build context → 从文件装**,
   要改 `configs/agents/claude-code.yaml` 的 `install:` 行(会进镜像 label → 进 provenance,记一笔)。
   TW 有 13/64 个任务就是死在这条上。脚本 §B 会在**容器里**探明文/TLS,先拿数据再动手。
2. **不要用 `unshare -Ur` 单 UID 模式**(我今天试过的那条路)。TW 实测:单 UID 命名空间
   无法 chown 到非 root uid,凡是带这类包的层都会失败。而且 OpenRUA 要的 `--userns=keep-id`
   本来就需要多 ID 映射。
3. **storage 必须 vfs**(overlay 需要本 pod 没有的 delegated cgroup),`~/podman-static/etc/storage.conf`
   已经是 vfs ✅。另注 `/tmp` 不跨 pod 重启存活 —— socket 与 `/tmp/dockercfg` 重启后都要重建。

另:TW 那边也独立撞到了 **Fable 5.1 要求 CLI ≥ 2.1.251**(它的 `claude-agent-sdk==0.2.132`
自带 2.1.224,报同一个 400),与 §6.1 互相印证。

进度实况:`podman-storage/` 34 K = **一个镜像都没有**;`openrua-local/runs/` 空;
最后一次尝试 `build-robot.log` 停在

```
building at STEP "RUN apt-get update && apt-get install -y ... ros-jazzy-moveit ...": exit status 100
```

即 **§4 的 build 都没过,§5 模拟器、§7 冒烟、§8 全量一律未开始**。
(`build.py:40` 只回显最后 2000 字符 stderr,真正的 apt 报错被截掉了 —— 复现时先手工
`docker run ros:jazzy` 跑那条 apt 看全文。)

### 0.1/0.2 历史记录(系统 podman 3.4.4 时期)

姊妹文档:`/storage/home/yehe8/TerminalWorld-Multimodal-Dev/RUNBOOK.local.md` —— **同一台
fair-sc 登录 pod、同一个 podman 3.4.4** 上把另一个容器化 agent harness 跑通的完整记录。
下面的判断大量依据它 + 本机实测。

### 阻断 1:没有 CNI dnsname 插件 → `--internal` 网络无 DNS

```
$ podman network create --internal probe
WARNING: dnsname and --internal networks are incompatible.
         dnsname plugin not configured for network probe
$ ls /usr/libexec/cni /opt/cni/bin
（空 —— 没有任何 CNI 插件)
```

网络**能建,但没有名字解析**。而 `runner/bringup.py:322` 建的正是
`docker network create --internal openrua-internal`,沙箱靠**容器名**解析 robot 与 proxy。
解析不了 → bring-up 必然失败,**无配置可绕**。

TerminalWorld 能在这台机器跑通,是因为它**从不创建 podman 网络**:任务容器 `--network none`,
agent 容器 `slirp4netns:allow_host_loopback=true`,控制器地址用环境变量
`TW_MM_AGENT_SERVER_HOST=10.0.2.2` 硬写死。**OpenRUA 没有对应的逃生舱。**

### 阻断 2:容器内没有 HTTPS → sandbox 镜像装不上 agent

容器出网**仅明文**(TerminalWorld runbook §2:TLS 到公网被拦截,`curl` 退出码 35)。
而 OpenRUA 的 sandbox 镜像靠 `npm install -g @anthropic-ai/claude-code@{version}` 装 agent
—— 会 SSL 失败。

宿主经会话代理可达 npm(实测 200),所以解法是 TerminalWorld 那套"宿主取包 → 塞进 build
context → 从文件装"的 npm 版(`npm pack` + `COPY` + 从 tarball 装),但要改 agent manifest
的 install 行。

### 出路

1. **换一台有真 Docker 或 podman ≥4 + netavark 的机器**(推荐)。两个阻断都是平台层问题。
   ⚠️ **不能用计算节点** —— TerminalWorld runbook §6:计算节点有 apptainer 但**完全没有网络**,
   代理变量指向的端口只存在于登录 pod。
2. **先问清那 1300 局是在哪跑的**。`experiments.md` 说 CaP-Bench 700 局 + LIBERO-PRO 600 局
   都跑完了,**说明某处已有一套能跑的环境** —— 直接复用即可。**这应该是第一步。**
3. ~~照 TerminalWorld 移植 OpenRUA~~ —— 不推荐。对方的清单是 12 处源码改动 + 8 个环境变量;
   OpenRUA 至少要改网络模型、build 路径、cgroup 选项、tinyproxy、npm 安装。数天工作,
   且 `provenance.json` 会偏离基线,破坏可比性 —— 而可比性是这个实验的全部意义。

**§4(build)及之后在此解除前无法执行。§6(模型接入)已可确定,见下。**

---

## 1. 已完成的主机准备 ✅

按顺序执行过,可重复执行(幂等):

```bash
# 1.1 docker 名字 —— 52 处硬编码 argv[0]="docker",无 container_engine 配置键
mkdir -p ~/.local/bin && ln -s "$(command -v podman)" ~/.local/bin/docker
export PATH="$HOME/.local/bin:$PATH"        # 每个跑 openrua 的 shell 都要有

# 1.2 非限定镜像名 —— 否则 FROM ros:jazzy 解析失败或交互式挂起(build 是 capture_output,会静默卡死)
mkdir -p ~/.config/containers
printf 'unqualified-search-registries = ["docker.io"]\n' >> ~/.config/containers/registries.conf

# 1.3 主机包(源码 checkout;console script 才会出现)
pip install --user -e /storage/home/yehe8/OpenRUA
pip install --user pytest
```

**1.4 `~/.openrua/config.yaml` 必须手写** —— `openrua config set` 只有六个 flag,
表达不了 `sandbox.run_args`:

```yaml
agent: claude-code
robot: panda
benchmark: libero_pro
sandbox:
  run_args: ["--userns=keep-id"]
```

之后再跑 `openrua config set --model …` 是安全的(`config.py:47` 先读入整个 YAML 再回写)。

### ⚠️ 陷阱:doctor 的引擎行是个假绿灯

```
$ openrua doctor
  "id": "docker", "severity": "ok", "detail": "docker version 3.4.4"
```

**podman 3.4.4 以 `docker` 名字被调用时会伪装成 docker**,输出 `docker version …` 而不是
`podman version …`。于是 `doctor/checks.py:87-97` 里 `"podman" in version` 的分支从不触发,
**`--userns=keep-id` 的强制检查被静默跳过**。

后果:doctor 不会提醒你缺 keep-id,但缺了它 rootless podman 下沙箱内的 `robot` 用户
写不了 `/workspace`。所以 1.4 必须手写,不能指望 doctor 兜底。

(同理,这个假绿灯也掩盖了 §0 的版本阻断 —— doctor **不检查 podman 版本**。)

### 自检结果

```
$ python -m pytest -q
2 failed, 267 passed, 6 skipped
```

两个失败都是需要真实引擎+镜像的用例(`tests/proxy/test_proxy.py::test_port_parameter_travels_build_to_up`、
`tests/sandbox/test_sandbox.py::test_up_refuses_a_corpse`,后者要求能拉到 `alpine:3.20`),
不是代码问题。CI 本身也是纯 CPU、全部 stub 掉容器调用的。

---

## 2. 现场实测环境

| 项 | 实测 | 判定 |
|---|---|---|
| 容器引擎 | podman **3.4.4**,无 docker | ⛔ 见 §0 |
| `/etc/subuid` | `yehe8:40722580:65536` | ✅ |
| SELinux | 无 `getenforce` | ✅ 非 enforcing,bind mount 无需 `:z` |
| `unqualified-search-registries` | 已设为 `["docker.io"]` | ✅ |
| 磁盘 `/storage/home` | 48 T 可用(fsx) | ✅ 需求约 50 GB |
| 核数 | 64 | ✅ |
| 主机 python | 3.13.5(`/opt/conda`) | ✅ `requires-python >=3.10` |
| PyPI 出网 | **通**(pip install 成功) | ✅ 降低 §5 风险 |
| GitHub 出网 | 通 | ✅ |
| `research.meta.ai` 等 | 403 from proxy after CONNECT | ⚠️ 见 §4 B1 |

---

## 3. 无 GPU 不是问题

`docs/simulation.md:85`:渲染走 EGL,无 GPU 时回落 llvmpipe,
"slow but correct, **and what the reported runs used**"。
已发表的 693/700 与 551/600 **就是软渲染跑出来的**。

- `libero_pro.yaml` 无 `gpus:` 键,`Install.gpus` 默认 `False` —— **什么都不用做,只要永远别设它**
- 镜像里写死 `ENV MUJOCO_GL=egl PYOPENGL_PLATFORM=egl`(`Dockerfile.jazzy:26`),无 OSMesa 路径
- LIBERO 桌面场景 ~65 ms/帧(`sensors.py:19`);相机已用 `rate_hz: 2` + `render_mode: on_demand` 压过
- 线程:`LP_NUM_THREADS = clamp(cpu_count//4, 4, 16)` → 本机 16。
  **单局串行时可把 `machine.backend.resources.render_threads` 调高**,默认的 /4 是为并发准备的
- doctor **没有** GPU 检查,也没有渲染检查 —— 与"CPU 是受支持默认"一致

---

## 4. 代理与镜像(阻断解除后)⛔

### B1. tinyproxy 没有 upstream ⏸

`openrua/proxy/tinyproxy.conf` 无 `Upstream` 指令,代理容器会**直连** `api.anthropic.com:443`。
本机在一个会拦截的出网代理后面。大概率需要先加一行再 build:

```
Upstream http <corp-proxy-host>:<port>
```

无配置键,只能改源码。改完记进本文件 —— 它会影响镜像 label,进而进 `provenance.json`。

### B2. 三个镜像(libero_pro 要 jazzy)

**先探通再 build**,省时间:

```bash
for h in registry-1.docker.io deb.nodesource.com registry.npmjs.org dl-cdn.alpinelinux.org \
         archive.ubuntu.com packages.ros.org; do
  printf '%-28s ' "$h"; curl -sS -m 10 -o /dev/null -w '%{http_code}\n' "https://$h/" 2>&1 | tail -1
done
```

```bash
openrua build robot   --distro jazzy                      # ros:jazzy + Mesa + MoveIt,~3-5 GB
openrua build sandbox --distro jazzy --agent claude-code  # + node20 + @anthropic-ai/claude-code,~2-3 GB
openrua build proxy   --agent claude-code                 # alpine + tinyproxy,~10 MB
```

任一 host 挂掉 build 就死,而 `sandbox/build.py:40` **只回显最后 2000 字符 stderr**。

---

## 5. 模拟器安装 ⛔

```bash
openrua install --bench libero_pro --print    # 先读脚本,逐条核对 URL
openrua install --bench libero_pro
openrua doctor panda --bench libero_pro       # 目标:除 login 行外零 error
```

- 装到 `~/.openrua/simulators/cap-x/`,venv `cap-x/.venv-libero`(py3.12 ↔ Jazzy)
- checkout `capgym/cap-x` @ `53e9966d` + 4 submodule + 一个 patch
- **`requirements.txt` 是 GPU 机器 `uv pip freeze` 出来的**,锁了 `torch==2.13.0` 和整套
  NVIDIA CUDA 13 wheel(`cuda-toolkit==13.0.3.0` 等),**无 CPU-only 变体**。
  无 GPU 也要拉 ~8-10 GB 用不上的 wheel。libero_pro 预算 **25-30 GB**,加镜像共约 50 GB
- 出网:`github.com` ✅、`pypi.org` ✅(已验证)、`astral.sh`(uv 下 3.12 解释器)⏸
- `~/.local/share/uv` 会以只读挂进 robot 容器**同路径**(`robot/sim/up.py:65`),必须存在且可读

---

## 6. Fable 5.1 接入 ⏸

两个约束锁死了路径:

- **`openrua bench` 没有 `--agent` / `--model`**(只有 `openrua run`/`agent` 有)。
  bench 的模型完全来自 config 的 `agent.model`。
- **仓库里不存在 API key 通路**。全仓 grep 无 `ANTHROPIC_API_KEY` / `ANTHROPIC_BASE_URL` /
  `ANTHROPIC_AUTH_TOKEN`;`claude_code.py` docstring 写着 "No API key anywhere."

### 6.0 模型访问:x2p 注入 CAT,**不需要任何 API key** ✅ 实测通过

```bash
curl -x http://127.0.0.1:10054 \
  http://anthropic.ai-gateway.x2p.facebook.net/v1/messages \
  -H 'Content-Type: application/json' -H 'anthropic-version: 2023-06-01' \
  -d '{"model":"claude-fable-5-1","max_tokens":16,
       "messages":[{"role":"user","content":"Reply with exactly: PONG"}]}'
# -> {"model":"claude-fable-5-1", ... "text":"PONG" ...}
```

- **准确 id 是 `claude-fable-5-1`**。网关对 id 严格:`fable-5-1`、`claude-5-1-fable`、
  `claude-5-1-fable-gcp-genai` 都不存在。**先探再断言**
- base URL:`http://anthropic.ai-gateway.x2p.facebook.net` —— **plain HTTP,不是 HTTPS:443**
- `ANTHROPIC_API_KEY` 需非空但**从不被读取**

⚠️ **`mg-api-*` 和 `LLM|...` 这类 key 在 fair-sc 上没有用** —— `api.metagen.ai` 不可路由,
且这些 key 对网关和 `api.anthropic.com` 都不认证(TerminalWorld runbook §1)。别浪费时间。

### 6.1 ⚠️ CLI 版本:Fable 5.1 要求 ≥ 2.1.251,而基线是 2.1.226

TerminalWorld 记录的真实报错:

```
400 Claude Code 2.1.224 does not support this model; version 2.1.251 or newer is required
```

- `experiments.md`:Opus 5 那 1300 局用的是 **Claude Code 2.1.226**
- npm 上 2.1.226 / 2.1.251 都在,latest 2.1.267(已查)

**所以 harness 无法完全保持不变。** Fable 5.1 在 2.1.226 上根本起不来。
取**满足下限的最低版本 2.1.251**,把漂移压到最小,并在结论里显式记一句
"agent CLI 2.1.226 → 2.1.251"—— 这是与基线之间已知的唯一变量。

推论:**effort 必须钉死 `high`**。既然 CLI 已经必须动,不能再叠加第二个变量。

### 6.2 fork 后的 benchmark 配置 ✅ 已完成并通过 schema 校验

`/storage/home/yehe8/openrua-local/libero_pro-fable.yaml`:

```yaml
agent:
  name: claude-code
  model: claude-fable-5-1
  version: 2.1.251        # preflight 会校验沙箱镜像里的 CLI 版本
  options:
    effort: high
```

模型串**完全不校验**(`AgentConfig.model: str | None`,无 enum 无正则),原样递给 `claude --model`。
`version` 是合法键,且 schema 注释说明"the sandbox image must carry it and **preflight checks it**"
—— 相当于自带安全网。

**注意 `Strict` / `extra="forbid"`:能改 value,不能加 key。** 加 `base_url:` 会被 pydantic 拒。
所以 base URL 只能走 6.3 的 token-file 缝隙。

镜像也要同版本:`openrua build sandbox --distro jazzy --agent claude-code@2.1.251`。

### 6.3 多行 token file 注入网关

`--token-file` 被原样交给 `docker exec --env-file`(`agents/base.py::exec_argv`),不解析不校验
—— 这是不改代码指向自定义端点的**唯一缝隙**:

```bash
umask 077
cat > ~/.openrua/fable.env <<'EOF'
CLAUDE_CODE_OAUTH_TOKEN=gateway-injects-cat
ANTHROPIC_API_KEY=gateway-injects-cat
ANTHROPIC_BASE_URL=http://anthropic.ai-gateway.x2p.facebook.net
EOF
chmod 600 ~/.openrua/fable.env
```

**里面没有真实凭据** —— CAT 由 x2p 代理注入,两个占位值只是为了非空。

- `--token-file` **只有 `openrua bench` 支持**。`up`/`run`/`agent` 走
  `prepare_profile(require_credentials=True)` 且从不传 token file —— **交互模式用不了,调试也得走 bench**
- `record.py::secret_strings_from_env_file` 把 env file 里所有 **≥20 字符**的值当机密,
  在 transcript 和 bridge.log 里替换成 `[REDACTED]`。base URL 会被打码 —— 无害,别误判

### 6.4 tinyproxy 要走上游 x2p,不是 HTTPS:443

上一版这里写错了。真实情况:网关是**明文 HTTP**,且只能经 x2p 到达。所以需要

1. `openrua/proxy/tinyproxy.conf` 加 `Upstream http 10.0.2.2:10054`
   (`10.0.2.2` 是 slirp4netns 眼中的宿主 loopback,x2p 在宿主 `127.0.0.1:10054`)
2. 白名单加网关 host:

```bash
openrua build proxy --whitelist "$(printf '%s\n' \
  '^api\.anthropic\.com$' '^anthropic\.ai-gateway\.x2p\.facebook\.net$')"
docker rm -f openrua-proxy    # 必须!
```

`proxy/up.py::ensure` **不会替换已在跑的代理**,只打一行 stderr 警告。换白名单后不 rm,
跑的还是旧镜像。

其余 adapter 的同源网关(备查):
`codex` → `http://azure-codex.ai-gateway.x2p.facebook.net/openai/v1`

### 6.4 预期噪音,不是故障

`doctor` 的 `check_login` 在没有 `.credentials.json` 时判 **error**,退出码 1。
走 token-file 时这是误报 —— `trial.py:222` 的 `require_credentials=token_file is None` 已经放行。

### 6.5 ⚠️ 配额行为会与基线不同

`libero_pro.yaml:44-48` 的注释:配额墙"comes from running at scale on **subscription accounts**,
not from the method, and a single-trial reproduction through an **API key** never meets one"。

Opus 5 那 700+600 局跑在订阅账号上(所以 `resume_on_quota_wall: true` 有意义)。
走网关 API key 时基本遇不到配额墙 —— **这本身不影响成功率,但 `operator_meta` 里的
`segments` / `suspended_seconds` / `resumes` 会与基线不可比**,读结果时注意。

---

## 7. 冒烟(1 局)⛔

```bash
cd /storage/home/yehe8/openrua-local
openrua bench --config /storage/home/yehe8/openrua-local/libero_pro-fable.yaml \
  --run-id fable51-smoke \
  --task-suite libero_10_task \
  --task-ids 0 --seeds 0 \
  --operator agent \
  --token-file ~/.openrua/fable.env \
  --runs-root /storage/home/yehe8/openrua-local/runs
```

### ⚠️ 范围写法是坏的,文档也是错的

`--task-ids 0-9` 会抛**未捕获的 `ValueError`** —— `runner/main.py` 只做
`[int(x) for x in s.split(",")]`。

`docs/running-experiments.md:14` 的示例和 `openrua benchmarks` 打印的提示(`list.py:112`)
**都写着 `0-9`,都是错的**。只有 README 用了正确的逗号形式。**永远写逗号列表。**

### 冒烟要确认的六件事

| # | 判据 | 在哪看 |
|---|---|---|
| 1 | `termination == self_finished`(非 `launcher_failed` / `anomaly`) | `result.json` |
| 2 | `operator_meta.model` 确实是 Fable 5.1 的 id —— 证明 fork 生效 | `result.json` |
| 3 | `--effort` / `--autocompact` 没被新模型拒(无条件传,被拒则进程直接死) | `<transcript>.stderr` |
| 4 | `gpu_render == false`,`container_engine` 记的是 podman | `provenance.json` |
| 5 | **真实单局墙钟 + `operator_meta.cost_usd`** ← 决定要不要排 200 局的唯一依据 | `result.json` |
| 6 | `preflight` 全绿,无渲染报错 | `result.json` / `bridge.log` |

---

## 8. 全量 200 局(**需另行批准**)⏸

参考成本(Opus 5,goal 两格):单局中位 **51 分钟**、90 分位 **234 分钟**、中位 **$9.6**。
200 局串行约**一周**连续机时,约 **$2-3 k**。Fable 5.1 单价未知,以冒烟实测为准。
⚠️ **LIBERO-10 是长程两段式任务,基线成功率更低(65/80 vs 79/79)** —— 失败局往往烧满
`active_wall_clock_minutes: 240` 才结束,所以这两格的**均值墙钟与成本会明显高于 goal 两格**,
不要拿 51 分钟的中位数直接外推。

```bash
cd /storage/home/yehe8/openrua-local
IDS=0,1,2,3,4,5,6,7,8,9

openrua bench --config ./libero_pro-fable.yaml --run-id fable51-libero10-task \
  --task-suite libero_10_task --task-ids $IDS --seeds $IDS \
  --operator agent --token-file ~/.openrua/fable.env --runs-root ./runs

openrua bench --config ./libero_pro-fable.yaml --run-id fable51-libero10-swap \
  --task-suite libero_10_swap --task-ids $IDS --seeds $IDS \
  --operator agent --token-file ~/.openrua/fable.env --runs-root ./runs
```

三个操作要点:

- **两格必须用不同 `--run-id`**。容器名 stem 是 `rc-{run_dir.name}-{task_id}-{seed}`,**不含 suite**;
  同 run-id 时一格的活容器会让另一格的过期锁看起来是 live 的
- **`.running` 锁判活会 `SystemExit`,杀掉整个剩余队列**,不只是那一局。
  重启前先 `openrua ps`(它的 `--runs-root` 也是**相对 cwd**)
- 并行只跑两格;ROS domain 自动分配(0-101 取最低空闲),`--ros-domain` **留空**。
  两个并发 sim 各 16 线程,64 核撑得住

---

## 9. 参考:协议与语义(与 experiments.md 逐条核对过 ✅)

| 项 | 值 | 出处 |
|---|---|---|
| suite 名 | `libero_10_task` / `libero_10_swap` | 本 fork 的 `task.suites`(见下) |
| 每 suite task 数 | **10** | `bddl_files/<suite>/` 各 10 个 `.bddl`(libero_10 两格已核对) |
| seed 语义 | 索引官方固定初始状态文件,**无 RNG**;出厂 50 个,seeds 0-9 = states 0-9 | `LiberoLoader.init_state` |
| `active_wall_clock_minutes` | 240 | `protocol` |
| `max_turns` | 500 | `protocol` |
| `resume_on_quota_wall` | **true**(唯一偏离 schema 默认的键) | `protocol` |
| `max_quota_wait_minutes` / `max_suspensions` | 360 / 4 | `protocol` |
| `stall_probe_timeout_s` | 600 → 超时判 `anomaly`,该局**不计数** | `trial.py:120` |
| `clock.mode` | `paused`(agent 思考时仿真时钟暂停) | `protocol` |
| shell 超时 10 min / 30 min | `bash_timeout_ms` / `bash_max_timeout_ms` | **在 `claude-code.yaml`,不在 protocol** |
| `success` | benchmark 自己的谓词,**逐步 latch(任一步成功即成功)** | `result.json` |

唯一的 CLI 协议覆盖是 `--wall-clock-min`;其余只能改 config。

`--task-suite` **不校验**是否在 `task.suites` 里 —— 拼错会一路带进容器,在 LIBERO 的
`get_benchmark_dict()[task_suite]` 里炸。

### 第一处:配置 ✅ 已完成

`libero_pro-fable.yaml` 的 `task.suites` 加了 `libero_10_swap, libero_10_task`。
runner 不读这个列表(它只影响 `openrua benchmarks` 的目录与可读性),但列上以免结果无法解释。
已用 `load_config` + `apply_suite_overrides('libero_10_task')` 过了 schema 校验。

`default_suite` 仍是 `libero_goal_task` —— 它只管 `openrua run/up` 交互模式,bench 不看,
且必须在 `task.suites` 里(`loader.py:350`),保持不动最省事。

两格的 bddl 与 init 文件就在仓库自带的 `libero-pro-suites.tar.gz` 里
(`bddl_files/libero_10_{task,swap}` 与 `init_files/…` 各 10 个,已核对),
**不需要额外下载**。但 `install.shell` 的解包判据是 `[ -d "$LIBERO/bddl_files/libero_goal_task" ]`
—— 若目标机器上是用**更早的 tarball** 装的,goal 目录已存在会导致**不再解包**,libero_10 就缺席。
换机器后先确认:`ls ~/.openrua/simulators/cap-x/capx/third_party/LIBERO-PRO/libero/libero/bddl_files/`
里有没有 `libero_10_task`;没有就手工 `tar xzf` 补一次。

### 第二处:必须从 `origin/main` 跑,本地 `main` 跑不了 ⛔(2026-09-11 查证)

原先这里写的是"要动的唯一一处",不对 —— 还有第二处,而且是硬的:**从哪套 git 历史跑**。

`OpenRUA` 本地 checkout 的 `main` 与 `origin/main` 是**两套无共同祖先的历史**
(`git merge-base main origin/main` 退出码 1),commit message 一路重复到 `Initial commit`
(本地 `040f57f` / 远端 `7b1b01a`)。本地领先 121、落后 139。

本地缺 `833ad4a`,而这个 fix 决定 LIBERO 能不能跑:
`environments/libero.py` 的 `write_libero_settings()` 在本地版里调
`find_spec("libero.libero")` —— **带点的名字会先 import 父包**,正是它要抢在前面阻止的那次 import。
LIBERO 于是在 stdin 上问 dataset 路径,而 bridge 上这个 stdin 就是控制通道,
这一问会**吞掉 host 的第一个请求**。远端版本改成查裸名 `libero`,再在磁盘上找内层目录。

本地 `openrua/configs/benchmarks/libero_pro.yaml` 也只有六格(无 libero_10);
`libero_pro-fable.yaml` 覆盖了它,所以不致命,但自带默认与本次实验不一致。

反过来,本地独有的是引擎批次(SAPIEN/ManiSkill、PyBullet/CALVIN、MuJoCo),
**与本实验无关** —— libero_pro 走 `simulator: robosuite`,两边都有。
远端还多 `18e1deb`(八格)与 `9a76fec`+`a4fc736`(`--agent`/`--model` 真正传进 compose;
`9a76fec` 留了条够不着的路径,`a4fc736` 补上),后者对钉死 `claude-fable-5-1` 有直接影响。

**结论:这两格从 `origin/main` 跑。** 基线那 65/100 与 80/100 也是远端代码出的,
从远端跑才能把差异压回"只有 CLI 版本"这一个变量(§6.1)。

`libero-pro-suites.tar.gz` 两边**字节相同**(blob `e101631`,331520 B),
所以上面那段关于解包判据的提醒对两边都成立,资产不是问题。

### ⚠️ 沙箱内 agent 是无提示全权执行

`claude_code.py:52-76` 无条件传 `--dangerously-skip-permissions`(并禁掉 WebSearch/WebFetch)。
设计上说得通 —— agent 跑在只有白名单代理出口的一次性容器里,每局重建 —— 但要知道这一点。

---

## 10. 待输入清单 ⏸

已解决(不再需要输入):~~模型 id~~ = `claude-fable-5-1`;~~网关 URL~~ =
`http://anthropic.ai-gateway.x2p.facebook.net`;~~凭据~~ = 不需要;
~~effort~~ = 钉死 `high`;~~上游代理~~ = x2p `10.0.2.2:10054`。

仍需确认:那 1300 局的环境 —— 见 §11。

---

## 11. 向跑过那 1300 局的同事取环境(当前唯一未决项)

已确认由团队里另一位同事跑的。复用现成环境比在这台 pod 上移植划算得多 ——
移植会让 `provenance.json` 偏离基线,而可比性是这个实验的全部意义。

### 旁证

- OpenRUA 仓库**只有 9 天历史**(2026-09-01 → 09-09,121 commit,作者 Zhaoyang Chu),
  **从未提交过任何 run 产物**
- 可行性算术:1300 局 × 中位 26–51 min ≈ **700+ 小时 trial 墙钟**,塞进 ≤216 小时,
  **至少 4 路并发**;考虑 p90 = 234 min 的长尾更可能是十几路。绝非单台 pod 顺序跑出

### 可直接转发的清单

> 想在 LIBERO-PRO 的 **LIBERO-10 两格**(`libero_10_task` + `libero_10_swap`)上补跑
> Claude Fable 5.1(对齐 Opus 5 的 65/100 + 80/100),
> 需要复用你跑那 1300 局的环境。麻烦确认几件事:
>
> 1. **机器**:主机名 / 集群 / 机型?我怎么申请访问权?
> 2. **容器引擎**:真 Docker 还是 podman?podman 的话版本 + 网络后端
>    (`podman --version`、`podman info --format '{{.Host.NetworkBackend}}'`)?
>    我这台 fair-sc 登录 pod 是 podman 3.4.4 且没有 CNI dnsname 插件,
>    OpenRUA 的 `--internal` 网络没有 DNS,沙箱解析不了 robot 和 proxy,起不来
> 3. **并发度**:同时跑几路?怎么调度(手工 / slurm / 其它)?
> 4. **一份 `provenance.json`**:任意 trial 的都行 —— 里面的 `host`、`container_engine`、
>    三个镜像 digest、`agent_cli`、`gpu_render` 一次就把环境说清了
> 5. **模型接入**:x2p 网关(`anthropic.ai-gateway.x2p.facebook.net`)还是订阅账号登录?
>    (`libero_pro.yaml` 里 `resume_on_quota_wall: true` 的注释暗示是订阅账号)
> 6. **Claude Code 版本**:确认是 2.1.226?
>    ⚠️ **Fable 5.1 要求 ≥ 2.1.251**,2.1.226 会 `400 ... does not support this model`。
>    你那边遇到过吗,或已有升级后的镜像?
> 7. **`runs/` 目录**:还在吗、在哪?想直接读 Opus 5 在 `libero_10_task` / `libero_10_swap`
>    这 200 局的 trial 产物做对照,而不是只看汇总表里的 65/100 与 80/100
> 8. **GPU**:那台机器有卡吗?(文档说已发表结果用 llvmpipe 软渲染,想确认在你们那边也成立)

### 两种走向

- **环境可用** → 在那台机器上从本文件 §5 往下执行,§0 的两个阻断自动消失。
  fork 好的 `libero_pro-fable.yaml` 可原样带过去
- **环境不可用 / 对方也在这台 pod** → 1300 局的数据来源需要重新核实,
  再评估移植(数天,不可比)还是另找机器

---

## 附:目录布局

```
/storage/home/yehe8/openrua-local/
  RUNBOOK.md                 ← 本文件
  libero_pro-fable.yaml      ← fork 的 benchmark 配置
  build-images.sh            ← 一键 build(登录终端)
  probe-container-egress.sh  ← 容器/宿主/x2p 三通道出网探测(登录终端)
  mkrosrepo.sh               ← §0.0b-4:从公开镜像 dpkg-repack 造本地 ROS apt 源
  serve-rosrepo.sh           ← 把本地源用 HTTP:8899 端出去,build 期间常驻
  patch-dockerfiles.py       ← apply/revert:两个 Dockerfile 改指本地源(包列表不动)
  ensure-podman.sh           ← 三个脚本共用的前置(受限会话门禁 + 起 podman service)
  rosrepo/                   ← ⭐ 本地 ROS apt 源(pool/ + Packages)。放在 NFS 是因为
                                /containers **pod 重启即清空**,见 §0.0b-5
  logs/                      ← 所有脚本日志。同理:别再写 /tmp
  runs/                      ← 所有 trial 产物

~/.openrua/
  config.yaml                ← 已写(含 sandbox.run_args)
  fable.env                  ← ⏸ 待创建,600,绝不进 git
  credentials/  simulators/
```

**为什么不放进 `/storage/home/yehe8/OpenRUA`**:它的 remote 是 `terminalworld/OpenRUA`,
**第三方上游仓库**。本地文件写进去有误提交到别人仓库的风险,凭据尤其不能。
