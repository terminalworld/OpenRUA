#!/bin/bash
# 共用前置:确认不是受限会话 + 拉起带正确 TMPDIR 的 podman service。
# 用法(其它脚本第一行):  source /storage/home/yehe8/openrua-local/ensure-podman.sh
#
# 为什么单独抽出来:2026-09-11 踩过 —— probe/mkrosrepo 在 service 还没起时就跑,
# 全部 "Cannot connect to Podman",但脚本继续往下走,造出一个**空的**本地源,
# 最后表现成 build 阶段的 404。前置必须每个脚本自己保证,不能靠执行顺序。

export PATH="$HOME/.local/bin:$PATH"          # ~/.local/bin/docker = 转发到静态 podman 6.1.1
SOCK=${SOCK:-/tmp/podman-static.sock}         # ⚠️ /tmp 不跨 pod 重启存活,重启后要重来
PM=${PM:-$HOME/podman-static/v611/usr/local/bin/podman}
WANT_CAP=000001ffffffffff
# buildah 把 build context 挂成一层 overlay,默认落在 /var/tmp —— 本 pod 的 /var/tmp 与
# /tmp 都是 overlayfs,overlay 套 overlay 内核直接 EINVAL。/containers 是 xfs,可以。
# remote build 的临时目录建在 **service 端**,所以要设在 service 的环境里。
export TMPDIR=${TMPDIR_OVERRIDE:-/containers/yehe8/tmp}

say() { printf '\n=== %s ===\n' "$*"; }
die() { printf '\n!!! %s\n' "$*"; exit 1; }

say "0. 调用者是否受限"
# ⚠️ 不要用 CapEff 判自己:任何非 root shell 的 CapEff 都是全 0,登录终端也是。
# 可靠判据:受限会话拦掉全部 setuid 程序 + chmod/chown。
/usr/bin/newuidmap --help >/dev/null 2>&1; NU=$?     # 登录终端 1 / 受限会话 126
/usr/bin/chmod --version >/dev/null 2>&1; CH=$?      # 登录终端 0 / 受限会话 126
echo "newuidmap rc=$NU  chmod rc=$CH"
if [ "$NU" = "126" ] || [ "$CH" = "126" ]; then
  die "这是受限会话(agent sandbox):setuid 程序与 chmod 被拦,它拉起的 service 建不了镜像。请在普通登录终端里跑。"
fi

say "A. podman service"
mkdir -p "$TMPDIR" || die "建不了 $TMPDIR"
SVC_PID=$(pgrep -f "podman system service" | head -1)
if [ -n "${SVC_PID:-}" ] && ! tr '\0' '\n' < "/proc/$SVC_PID/environ" 2>/dev/null | grep -qx "TMPDIR=$TMPDIR"; then
  echo "现有 service(pid=$SVC_PID)没有 TMPDIR=$TMPDIR,换掉它"
  kill "$SVC_PID" 2>/dev/null; sleep 3; rm -f "$SOCK"; SVC_PID=""
fi
if [ -n "${SVC_PID:-}" ]; then
  # service 自己 re-exec 进 userns,在那里持有全部能力 —— 这一处 CapEff 判据才有效
  SVC_CAP=$(grep CapEff "/proc/$SVC_PID/status" 2>/dev/null | awk '{print $2}')
  echo "已在运行 pid=$SVC_PID CapEff=$SVC_CAP"
  [ "$SVC_CAP" != "$WANT_CAP" ] && echo "警告:期望 $WANT_CAP。若后面容器出网探测不通,kill $SVC_PID 让脚本重起。"
else
  echo "拉起 $SOCK"
  # unset 代理:session proxy 只对宿主有效,service 用它反而拿到 403
  ( unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY
    CONTAINERS_CONF="$HOME/podman-static/etc/containers.conf" \
    CONTAINERS_STORAGE_CONF="$HOME/podman-static/etc/storage.conf" \
    TMPDIR="$TMPDIR" \
      setsid nohup "$PM" system service --time=0 "unix://$SOCK" \
        >/tmp/podman-service.log 2>&1 < /dev/null & )
  sleep 8
  SVC_PID=$(pgrep -f "podman system service" | head -1)
  [ -z "${SVC_PID:-}" ] && { cat /tmp/podman-service.log; die "service 起不来"; }
  SVC_CAP=$(grep CapEff "/proc/$SVC_PID/status" | awk '{print $2}')
  echo "pid=$SVC_PID CapEff=$SVC_CAP  (期望 $WANT_CAP;不符则以容器内实测为准)"
fi
docker info --format 'engine {{.Version.Version}}  net {{.Host.NetworkBackend}}  storage {{.Store.GraphDriverName}}' \
  || die "socket 连不上"
# storage 必须是 vfs:overlay 需要本 pod 没有的 delegated cgroup
