#!/usr/bin/env bash
# 在【登录终端】跑。免白名单地造一个本地 ROS apt 源。
#
# 原理:packages.ros.org 不通,但 Docker Hub 通。官方 ROS debs 已经装在若干公开镜像里,
# 用 dpkg-repack 把它们【原样还原成 .deb】(dpkg 元数据、依赖、文件清单全保留),
# 汇成一个本地 apt 源。这样两个 Dockerfile 的 apt install 包列表【一字不改】就能装上。
#
#   bash /storage/home/yehe8/openrua-local/mkrosrepo.sh 2>&1 | tee /tmp/mkrosrepo.log
#
# 产物: $OUT/{pool,Packages,Packages.gz}   之后用 serve-rosrepo.sh 起 HTTP。
set -uo pipefail

# 受限会话门禁 + podman service。⚠️ 必须在任何 docker 调用之前 ——
# 2026-09-11 踩过:service 没起,下面全部静默失败,造出空源,直到 build 才报 404。
source /storage/home/yehe8/openrua-local/ensure-podman.sh

# ⚠️ 必须落在 /storage/home(NFS,持久)。/containers 是 pod 本地盘,**pod 重启即清空**
# —— 2026-09-11 15:18 的 pod 重启把已经造好的 358 个 deb 连同 podman 镜像库一起抹了。
OUT=${OUT:-/storage/home/yehe8/openrua-local/rosrepo}
# 源镜像:第一个提供 moveit 全栈,第二个补 image_view 等感知包。
# ⚠️ desktop-full 在 **osrf/ros** 下,不在 library/ros —— 官方 library/ros 的 jazzy
# 只有 ros-core / ros-base / perception 三个变体(写成 library 会 "manifest unknown")。
SRC_IMAGES=${SRC_IMAGES:-"docker.io/moveit/moveit2:jazzy-release docker.io/osrf/ros:jazzy-desktop-full"}

mkdir -p "$OUT/pool" || die "建不了 $OUT/pool"

for img in $SRC_IMAGES; do
  say "repack from $img"
  docker run --rm --network=host -v "$OUT:/out" "$img" bash -c '
    set -e
    # ROS 源不可达,拿掉它,否则 apt-get update 非零退出
    rm -f /etc/apt/sources.list.d/ros2*.list /etc/apt/sources.list.d/ros2*.sources
    apt-get update -qq
    apt-get install -y -qq --no-install-recommends dpkg-repack >/dev/null
    cd /out/pool
    # pod 重启会在 repack 中途杀死进程,留下截断的 .deb —— 而下面的跳过逻辑只看文件名,
    # 会把坏文件当成已完成。每轮先把不可读的清掉,让它们重新 repack。
    bad=0
    for f in *.deb; do
      [ -e "$f" ] || break
      dpkg-deb --field "$f" Package >/dev/null 2>&1 || { rm -f "$f"; bad=$((bad+1)); }
    done
    [ "$bad" -gt 0 ] && echo "  清掉 $bad 个损坏的 deb(上次中断留下的)"
    pkgs=$(dpkg-query -Wf "\${Package} \${Status}\n" | awk "/install ok installed/ && \$1 ~ /^ros-/ {print \$1}")
    n=$(echo "$pkgs" | grep -c . || true); echo "  $n 个 ros-* 包待 repack"
    [ "$n" -eq 0 ] && { echo "  !!! 这个镜像里没有 ros-* 包,源镜像选错了"; exit 3; }
    i=0
    for p in $pkgs; do
      i=$((i+1))
      ls "${p}_"*.deb >/dev/null 2>&1 && continue      # 已由上一个源镜像产出,跳过
      dpkg-repack "$p" >/dev/null 2>&1 || echo "  WARN repack failed: $p"
      [ $((i % 50)) -eq 0 ] && echo "  ... $i/$n"
    done
    echo "  done: $(ls /out/pool/*.deb 2>/dev/null | wc -l) debs in pool"
  ' || echo "!!! $img repack 未正常结束(rc=$?),继续下一个源"
done

# --- 合成 ros-jazzy-moveit 元包 ---------------------------------------------
# moveit2 镜像是从组件包装的,没装那个**空壳元包**,于是 dpkg-repack 也拿不到它,
# 而 Dockerfile 的包列表里写的正是 `ros-jazzy-moveit`。
# 元包不含任何文件,内容只有 Depends,而 Depends 是 bloom 从上游 package.xml 的
# exec_depend 逐条生成的。已核对 moveit2 分支 jazzy 的 moveit/package.xml:
#   moveit_core / moveit_planners / moveit_plugins / moveit_ros / moveit_setup_assistant
# 五个,全部已在池中(均 2.12.4)。照这五条合成 = 与官方元包等价,装出来的文件集不变。
if ! ls "$OUT"/pool/ros-jazzy-moveit_*.deb >/dev/null 2>&1; then
  say "合成 ros-jazzy-moveit 元包(上游 package.xml 的 5 条 exec_depend)"
  docker run --rm --network=host -v "$OUT:/out" docker.io/library/ubuntu:24.04 bash -c '
    set -e
    cd /out/pool
    core=$(ls ros-jazzy-moveit-core_*_amd64.deb 2>/dev/null | head -1)
    [ -z "$core" ] && { echo "  !!! 池里没有 ros-jazzy-moveit-core,不能定版本"; exit 4; }
    ver=$(basename "$core" | cut -d_ -f2)
    for d in core planners plugins ros setup-assistant; do
      ls ros-jazzy-moveit-${d}_*_amd64.deb >/dev/null 2>&1 || { echo "  !!! 缺依赖 moveit-$d"; exit 4; }
    done
    mkdir -p /tmp/meta/DEBIAN
    cat > /tmp/meta/DEBIAN/control <<EOF
Package: ros-jazzy-moveit
Version: $ver
Architecture: amd64
Maintainer: openrua-local <synthesized>
Section: misc
Priority: optional
Depends: ros-jazzy-moveit-core, ros-jazzy-moveit-planners, ros-jazzy-moveit-plugins, ros-jazzy-moveit-ros, ros-jazzy-moveit-setup-assistant
Description: Meta package that contains all essential packages of MoveIt 2
 Locally synthesized from moveit2@jazzy moveit/package.xml exec_depend list;
 the upstream metapackage ships no files, only these dependencies.
EOF
    dpkg-deb --build -Znone /tmp/meta "/out/pool/ros-jazzy-moveit_${ver}_amd64.deb" >/dev/null
    echo "  合成: ros-jazzy-moveit_${ver}_amd64.deb"
  ' || die "元包合成失败"
fi

NDEB=$(ls "$OUT"/pool/*.deb 2>/dev/null | wc -l)
[ "$NDEB" -eq 0 ] && die "pool 是空的 —— 一个 deb 都没造出来。别往下走,先看上面的报错。"

say "生成索引($NDEB 个 deb)"
docker run --rm --network=host -v "$OUT:/out" docker.io/library/ubuntu:24.04 bash -c '
  set -e
  apt-get update -qq
  apt-get install -y -qq --no-install-recommends dpkg-dev >/dev/null
  cd /out && dpkg-scanpackages pool /dev/null > Packages 2>/dev/null
  gzip -9kf Packages
  echo "  $(grep -c ^Package: Packages) 个包已索引,共 $(du -sh /out/pool | cut -f1)"
' || die "索引生成失败"

# 自检:apt 只认根目录下的 Packages(flat repo 的 "./" 分发)
[ -s "$OUT/Packages" ] || die "$OUT/Packages 不存在或为空 —— build 阶段会 404"

# --- 覆盖率自检:两个 Dockerfile 点名要的 ros 包一个都不能少 -----------------
say "覆盖率自检"
MISS=0
for p in ros-jazzy-control-msgs ros-jazzy-tf2-ros-py ros-jazzy-moveit \
         ros-jazzy-moveit-resources-panda-moveit-config ros-jazzy-robot-state-publisher \
         ros-jazzy-image-view ros-jazzy-cv-bridge ros-jazzy-tf2-tools ros-jazzy-tf2-ros \
         ros-jazzy-urdfdom-py ros-jazzy-moveit-msgs; do
  v=$(awk -v p="$p" '$1=="Package:" && $2==p {f=1} f && $1=="Version:" {print $2; exit}' "$OUT/Packages")
  printf '  %-50s %s\n' "$p" "${v:-*** MISSING ***}"
  [ -z "$v" ] && MISS=1
done
[ "$MISS" = 1 ] && die "有包缺失,build 一定会 exit 100。先补源镜像,别往下走。"

say "本地源就绪"
echo "  路径: $OUT"
echo "  版本清单(进 provenance 记一笔): $OUT/Packages"
echo "  下一步: bash /storage/home/yehe8/openrua-local/serve-rosrepo.sh"
