#!/usr/bin/env bash
# 在【登录终端】跑。目的:测出容器出网白名单的真实边界。
# agent 会话完全没有直连出网(连 archive.ubuntu.com 都 000),所以这份数据只能在这里取。
#
#   bash /storage/home/yehe8/openrua-local/probe-container-egress.sh 2>&1 | tee /tmp/egress2.log
set -uo pipefail

# ⚠️ 必须先起 podman service,否则下面的 docker run 全部 "Cannot connect to Podman"
source /storage/home/yehe8/openrua-local/ensure-podman.sh

HOSTS_HTTP="archive.ubuntu.com security.ubuntu.com packages.ros.org snapshots.ros.org repo.ros2.org"
HOSTS_HTTPS="registry.npmjs.org deb.nodesource.com conda.anaconda.org api.anaconda.org \
repo.anaconda.com pypi.org files.pythonhosted.org github.com codeload.github.com \
objects.githubusercontent.com raw.githubusercontent.com proxy.golang.org \
ghcr.io pkg-containers.githubusercontent.com quay.io cdn.quay.io public.ecr.aws \
registry-1.docker.io auth.docker.io production.cloudfront.docker.com \
cdn.jsdelivr.net astral.sh"

say "1. 容器内(--network=host,与 build 同路径)"
# 用 ubuntu:24.04 + curl:alpine 的 busybox wget 分不出 TLS 失败与 404
docker run --rm --network=host docker.io/library/ubuntu:24.04 bash -c '
  apt-get update -qq >/dev/null 2>&1
  apt-get install -y -qq curl ca-certificates >/dev/null 2>&1
  for h in '"$HOSTS_HTTP"'; do
    printf "  %-6s %-42s %s\n" http "$h" "$(curl -sS -m 12 -o /dev/null -w "%{http_code}" http://$h/ 2>&1 | tail -1)"
  done
  for h in '"$HOSTS_HTTPS"'; do
    printf "  %-6s %-42s %s\n" https "$h" "$(curl -sS -m 12 -o /dev/null -w "%{http_code}" https://$h/ 2>&1 | tail -1)"
  done
'

say "2. 宿主(登录终端),不经代理"
# ⚠️ 不能写 `env -u ... probe ...` —— probe 是 shell 函数,env 找不到它(已踩)。
# 用 curl 自己的 --noproxy '*' 绕开环境里的代理变量。
hprobe() { printf '  %-6s %-42s %s\n' "$1" "$2" \
  "$(curl -sS -m 12 --noproxy '*' -o /dev/null -w '%{http_code}' "$1://$2/" 2>&1 | tail -1)"; }
for h in $HOSTS_HTTP;  do hprobe http  "$h"; done
for h in $HOSTS_HTTPS; do hprobe https "$h"; done

say "3. 宿主经 x2p(127.0.0.1:${CPE_RUST_X2P_HTTP1_PROXY_PORT:-10054})"
PX="http://127.0.0.1:${CPE_RUST_X2P_HTTP1_PROXY_PORT:-10054}"
if ! timeout 3 bash -c "</dev/tcp/127.0.0.1/${CPE_RUST_X2P_HTTP1_PROXY_PORT:-10054}" 2>/dev/null; then
  echo "  x2p 端口没在监听 —— 整节跳过(全 000 只说明代理不在,不代表 host 不可达)"
else
  for h in $HOSTS_HTTP $HOSTS_HTTPS; do
    printf '  %-42s %s\n' "$h" "$(curl -sS -m 12 -x "$PX" -o /dev/null -w '%{http_code}' "https://$h/" 2>&1 | tail -1)"
  done
fi

say "4. 判据"
cat <<'EOF'
  packages.ros.org 任一路径 200/30x  -> 白名单已开,直接用原版 Dockerfile
  容器内 registry-1.docker.io + production.cloudfront.docker.com 都通
                                     -> §0.0b-4 的 dpkg-repack 方案可行(首选)
  容器内 conda.anaconda.org 通       -> RoboStack 兜底可行(大偏离,末选)
  容器内 ghcr.io + pkg-containers.githubusercontent.com 通 -> 源镜像可扩到 ghcr
EOF
